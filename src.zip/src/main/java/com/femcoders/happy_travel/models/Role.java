package com.femcoders.happy_travel.models;


public enum Role {
    USER,
    ADMIN
}